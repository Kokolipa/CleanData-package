# Import other subclasses similarly
from .anomalies import Anomalies  # noqa: F401
from .find_treat_duplicates import FindTreatDuplicates  # noqa: F401
from .memory import Memory  # noqa: F401
from .text_typos import TextTypos  # noqa: F401
from .treat_na import TreatNA  # noqa: F401
